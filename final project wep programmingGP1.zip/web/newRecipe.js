document.addEventListener("DOMContentLoaded", function() {
    const recipes = JSON.parse(localStorage.getItem('userRecipes')) || {};

    function getRecipeNameFromURL() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('recipe');
    }

    function loadRecipe(recipeName, index = 0) {
        const title = document.getElementById("recipe-title");
        title.textContent = recipeName;

        const content = document.getElementById("recipe-content");
        let ingredientsList = '';
        let stepsList = '';

        if (recipes[recipeName] && recipes[recipeName][index]) {
            const { ingredients, steps } = recipes[recipeName][index];
            ingredientsList = ingredients.map(ingredient => `<li contenteditable="true">${ingredient}</li>`).join("");
            stepsList = steps.map(step => `<li contenteditable="true">${step}</li>`).join("");
        } else {
            ingredientsList = `
                <li contenteditable="true"></li>
                <li contenteditable="true"></li>
                <li contenteditable="true"></li>
            `;
            stepsList = `
                <li contenteditable="true"></li>
                <li contenteditable="true"></li>
                <li contenteditable="true"></li>
            `;
        }

        content.innerHTML = `
            <h2>Ingredients:</h2>
            <ul id="ingredients-list">${ingredientsList}</ul>
            <h2>Steps:</h2>
            <ol id="steps-list">${stepsList}</ol>
        `;

        updateButtons(index, recipeName);
    }

    function updateButtons(index, recipeName) {
        const nextButton = document.getElementById("next-recipe");
        const prevButton = document.getElementById("prev-recipe");

        if (index === 0) {
            prevButton.style.display = 'none';
        } else {
            prevButton.style.display = 'inline-block';
        }

        if (!recipes[recipeName] || index >= recipes[recipeName].length - 1) {
            nextButton.style.display = 'inline-block';
        } else {
            nextButton.style.display = 'inline-block';
        }
    }

    const currentRecipeName = getRecipeNameFromURL();
    let currentRecipeIndex = 0;

    function saveRecipe() {
        const ingredients = Array.from(document.getElementById("ingredients-list").children).map(item => item.textContent);
        const steps = Array.from(document.getElementById("steps-list").children).map(item => item.textContent);
        const newRecipe = { ingredients, steps };

        if (!recipes[currentRecipeName]) {
            recipes[currentRecipeName] = [];
        }

        recipes[currentRecipeName][currentRecipeIndex] = newRecipe;
        localStorage.setItem('userRecipes', JSON.stringify(recipes));

        alert('Recipe saved!');
        updateButtons(currentRecipeIndex, currentRecipeName);
    }

    function deleteRecipe() {
        if (recipes[currentRecipeName] && recipes[currentRecipeName][currentRecipeIndex]) {
            recipes[currentRecipeName].splice(currentRecipeIndex, 1);
            if (recipes[currentRecipeName].length === 0) {
                delete recipes[currentRecipeName];
            }
            localStorage.setItem('userRecipes', JSON.stringify(recipes));
            alert('Recipe deleted!');
            window.location.href = 'recipes.html';
        }
    }

    function showNextRecipe() {
        currentRecipeIndex++;
        loadRecipe(currentRecipeName, currentRecipeIndex);
    }

    function showPreviousRecipe() {
        if (currentRecipeIndex > 0) {
            currentRecipeIndex--;
            loadRecipe(currentRecipeName, currentRecipeIndex);
        }
    }

    document.getElementById("save-recipe").addEventListener("click", saveRecipe);
    document.getElementById("delete-recipe").addEventListener("click", deleteRecipe);
    document.getElementById("next-recipe").addEventListener("click", showNextRecipe);
    document.getElementById("prev-recipe").addEventListener("click", showPreviousRecipe);

    loadRecipe(currentRecipeName, currentRecipeIndex);
});
