document.addEventListener("DOMContentLoaded", function() {
    let recipes = JSON.parse(localStorage.getItem('userRecipes'))|| {
        "Spaghetti Bolognese": [
            {
                ingredients: [
                    "200g spaghetti",
                    "100g minced beef",
                    "1 onion, chopped",
                    "2 cloves garlic, minced",
                    "400g can of tomatoes",
                    "2 tbsp olive oil",
                    "Salt and pepper to taste"
                ],
                steps: [
                    "Cook the spaghetti according to the package instructions.",
                    "In a large pan, heat the olive oil over medium heat.",
                    "Add the chopped onion and garlic, and sauté until translucent.",
                    "Add the minced beef and cook until browned.",
                    "Pour in the canned tomatoes, season with salt and pepper, and let it simmer for 20 minutes.",
                    "Serve the sauce over the cooked spaghetti."
                ]
            },
            {
                ingredients: [
                    "250g spaghetti",
                    "150g ground pork",
                    "1 carrot, grated",
                    "2 celery sticks, chopped",
                    "500ml beef stock",
                    "3 tbsp tomato paste",
                    "1 tbsp balsamic vinegar"
                ],
                steps: [
                    "Cook the spaghetti according to the package instructions.",
                    "In a pot, heat some olive oil and sauté the carrot and celery.",
                    "Add the ground pork and cook until browned.",
                    "Stir in the tomato paste, balsamic vinegar, and beef stock.",
                    "Simmer for 30 minutes until thickened.",
                    "Serve over spaghetti and garnish with parmesan cheese."
                ]
            },
            {
                ingredients: [
                    "200g spaghetti",
                    "100g ground turkey",
                    "1 zucchini, chopped",
                    "1 bell pepper, chopped",
                    "1 can of crushed tomatoes",
                    "1 tsp dried oregano",
                    "1 tsp dried basil"
                ],
                steps: [
                    "Cook the spaghetti according to the package instructions.",
                    "In a skillet, cook the ground turkey until no longer pink.",
                    "Add the chopped zucchini and bell pepper, and cook until softened.",
                    "Pour in the crushed tomatoes and add the dried herbs.",
                    "Simmer for 20 minutes and serve over the spaghetti."
                ]
            }
        ],
        "Chicken Curry": [
            {
                ingredients: [
                    "500g chicken breast, diced",
                    "1 onion, chopped",
                    "2 cloves garlic, minced",
                    "1 tbsp ginger, grated",
                    "2 tbsp curry powder",
                    "400ml coconut milk",
                    "1 can of tomatoes",
                    "2 tbsp vegetable oil",
                    "Salt and pepper to taste"
                ],
                steps: [
                    "Heat the vegetable oil in a large pan over medium heat.",
                    "Add the chopped onion, garlic, and ginger, and sauté until fragrant.",
                    "Add the diced chicken and cook until browned.",
                    "Stir in the curry powder and cook for another minute.",
                    "Pour in the coconut milk and tomatoes, season with salt and pepper, and let it simmer for 25 minutes.",
                    "Serve with rice."
                ]
            },
            {
                ingredients: [
                    "1 kg chicken thighs",
                    "2 onions, chopped",
                    "3 cloves garlic, minced",
                    "1 tbsp ginger paste",
                    "3 tbsp curry powder",
                    "1 tsp turmeric powder",
                    "1 tsp cumin powder",
                    "400ml coconut milk",
                    "2 tomatoes, chopped",
                    "3 tbsp vegetable oil",
                    "Salt and pepper to taste"
                ],
                steps: [
                    "Heat the vegetable oil in a large pan over medium heat.",
                    "Add the chopped onions, garlic, and ginger, and sauté until golden.",
                    "Add the chicken thighs and cook until browned.",
                    "Mix in the curry powder, turmeric, and cumin, and cook for a couple of minutes.",
                    "Pour in the coconut milk and add the chopped tomatoes.",
                    "Season with salt and pepper, and let it simmer for 30-40 minutes.",
                    "Serve with naan bread or rice."
                ]
            },
            {
                ingredients: [
                    "800g chicken thighs, bone-in",
                    "1 large onion, finely chopped",
                    "4 cloves garlic, minced",
                    "1 tbsp fresh ginger, grated",
                    "2 tbsp curry powder",
                    "1 tsp ground coriander",
                    "1 tsp ground cumin",
                    "1 tsp paprika",
                    "1 tsp chili powder",
                    "400ml coconut milk",
                    "1 cup chicken broth",
                    "2 potatoes, peeled and cubed",
                    "3 tbsp vegetable oil",
                    "Salt and pepper to taste"
                ],
                steps: [
                    "Heat the vegetable oil in a large pot over medium heat.",
                    "Add the onion, garlic, and ginger, and cook until softened.",
                    "Add the chicken thighs and brown them on all sides.",
                    "Stir in the curry powder, ground coriander, ground cumin, paprika, and chili powder, and cook for a couple of minutes.",
                    "Add the coconut milk, chicken broth, and potatoes.",
                    "Season with salt and pepper, and bring to a boil.",
                    "Reduce the heat and simmer for 35-40 minutes until the chicken is cooked through and the potatoes are tender.",
                    "Serve with steamed rice."
                ]
            }
        ],

        "Beef Stroganoff": [
            {
                ingredients: [
                    "500g beef sirloin steak, thinly sliced",
                    "1 onion, finely chopped",
                    "2 cloves garlic, minced",
                    "200g mushrooms, sliced",
                    "1 cup beef broth",
                    "1 cup sour cream",
                    "2 tbsp all-purpose flour",
                    "2 tbsp olive oil",
                    "Salt and pepper to taste",
                    "Fresh parsley for garnish"
                ],
                steps: [
                    "Heat olive oil in a large skillet over medium-high heat.",
                    "Add sliced beef and cook until browned. Remove beef from skillet and set aside.",
                    "In the same skillet, add chopped onion and garlic. Sauté until onion is translucent.",
                    "Add sliced mushrooms and cook until they release their moisture.",
                    "Sprinkle flour over the vegetables and stir well to combine.",
                    "Pour in beef broth and stir until the mixture thickens.",
                    "Return the cooked beef to the skillet and simmer for 10 minutes.",
                    "Stir in sour cream and season with salt and pepper.",
                    "Serve hot over cooked egg noodles or rice, garnished with fresh parsley."
                ]
            },
            {
                ingredients: [
                    "600g beef tenderloin, thinly sliced",
                    "1 onion, chopped",
                    "3 cloves garlic, minced",
                    "250g button mushrooms, sliced",
                    "1 cup beef stock",
                    "1 cup heavy cream",
                    "2 tbsp butter",
                    "2 tbsp all-purpose flour",
                    "2 tbsp Worcestershire sauce",
                    "Salt and pepper to taste",
                    "Chopped fresh chives for garnish"
                ],
                steps: [
                    "In a large skillet, melt butter over medium heat.",
                    "Add sliced beef and cook until browned. Remove beef from skillet and set aside.",
                    "In the same skillet, add chopped onion and garlic. Sauté until softened.",
                    "Add sliced mushrooms and cook until golden brown.",
                    "Sprinkle flour over the vegetables and stir well to combine.",
                    "Pour in beef stock and Worcestershire sauce. Stir until the mixture thickens.",
                    "Return the cooked beef to the skillet and simmer for 5 minutes.",
                    "Stir in heavy cream and season with salt and pepper.",
                    "Serve hot over cooked rice or mashed potatoes, garnished with chopped fresh chives."
                ]
            },
            {
                ingredients: [
                    "700g beef chuck roast, cut into thin strips",
                    "2 onions, sliced",
                    "4 cloves garlic, minced",
                    "200g cremini mushrooms, sliced",
                    "1 1/2 cups beef broth",
                    "1 cup sour cream",
                    "3 tbsp all-purpose flour",
                    "3 tbsp vegetable oil",
                    "2 tbsp Dijon mustard",
                    "Salt and pepper to taste",
                    "Chopped fresh parsley for garnish"
                ],
                steps: [
                    "Heat vegetable oil in a large skillet over medium-high heat.",
                    "Add beef strips and cook until browned. Remove beef from skillet and set aside.",
                    "In the same skillet, add sliced onions and garlic. Sauté until onions are caramelized.",
                    "Add sliced mushrooms and cook until tender.",
                    "Sprinkle flour over the vegetables and stir well to combine.",
                    "Pour in beef broth and Dijon mustard. Stir until the mixture thickens.",
                    "Return the cooked beef to the skillet and simmer for 15 minutes.",
                    "Stir in sour cream and season with salt and pepper.",
                    "Serve hot over cooked wide egg noodles, garnished with chopped fresh parsley."
                ]
            }
        ],
        "Caesar Salad": [
            {
                ingredients: [
                    "1 head romaine lettuce, chopped",
                    "1/2 cup croutons",
                    "1/4 cup grated Parmesan cheese",
                    "1/4 cup Caesar dressing",
                    "1 lemon, juiced",
                    "2 tbsp olive oil",
                    "Salt and pepper to taste"
                ],
                steps: [
                    "In a large bowl, combine chopped romaine lettuce and croutons.",
                    "In a small bowl, whisk together Caesar dressing, lemon juice, and olive oil.",
                    "Pour the dressing over the salad and toss to coat evenly.",
                    "Sprinkle grated Parmesan cheese on top.",
                    "Season with salt and pepper to taste.",
                    "Serve immediately as a side dish or add grilled chicken for a main course."
                ]
            },
            {
                ingredients: [
                    "1 head romaine lettuce, chopped",
                    "1 cup cherry tomatoes, halved",
                    "1/2 cup croutons",
                    "1/4 cup grated Parmesan cheese",
                    "1/4 cup Caesar dressing",
                    "1 lemon, juiced",
                    "2 tbsp olive oil",
                    "Salt and pepper to taste"
                ],
                steps: [
                    "In a large bowl, combine chopped romaine lettuce, cherry tomatoes, and croutons.",
                    "In a small bowl, whisk together Caesar dressing, lemon juice, and olive oil.",
                    "Pour the dressing over the salad and toss to coat evenly.",
                    "Sprinkle grated Parmesan cheese on top.",
                    "Season with salt and pepper to taste.",
                    "Serve immediately as a refreshing and satisfying meal."
                ]
            },
            {
                ingredients: [
                    "1 head romaine lettuce, chopped",
                    "1 cup cooked chicken breast, diced",
                    "1/2 cup croutons",
                    "1/4 cup grated Parmesan cheese",
                    "1/4 cup Caesar dressing",
                    "1 lemon, juiced",
                    "2 tbsp olive oil",
                    "Salt and pepper to taste"
                ],
                steps: [
                    "In a large bowl, combine chopped romaine lettuce, diced chicken breast, and croutons.",
                    "In a small bowl, whisk together Caesar dressing, lemon juice, and olive oil.",
                    "Pour the dressing over the salad and toss to coat evenly.",
                    "Sprinkle grated Parmesan cheese on top.",
                    "Season with salt and pepper to taste.",
                    "Serve immediately as a hearty and delicious meal."
                ]
            }
        ],
        "Vegetarian Pizza": [
            {
                ingredients: [
                    "1 pre-made pizza dough",
                    "1/2 cup pizza sauce",
                    "1 cup shredded mozzarella cheese",
                    "1/2 cup sliced mushrooms",
                    "1/2 cup sliced bell peppers",
                    "1/4 cup sliced black olives",
                    "1/4 cup sliced red onions",
                    "1/4 cup sliced tomatoes",
                    "1/4 cup fresh basil leaves",
                    "1 tbsp olive oil",
                    "Salt and pepper to taste"
                ],
                steps: [
                    "Preheat the oven to 425°F (220°C).",
                    "Roll out the pizza dough on a floured surface to your desired thickness.",
                    "Transfer the dough to a pizza pan or baking sheet.",
                    "Spread the pizza sauce evenly over the dough, leaving a small border around the edges.",
                    "Sprinkle the shredded mozzarella cheese over the sauce.",
                    "Top the pizza with mushrooms, bell peppers, black olives, red onions, and tomatoes.",
                    "Drizzle olive oil over the vegetables and season with salt and pepper.",
                    "Bake in the preheated oven for 12-15 minutes, or until the crust is golden brown and the cheese is bubbly.",
                    "Remove from the oven and sprinkle fresh basil leaves over the hot pizza.",
                    "Slice and serve immediately."
                ]
            },
            {
                ingredients: [
                    "1 pre-made pizza crust",
                    "1/2 cup marinara sauce",
                    "1 cup shredded mozzarella cheese",
                    "1/2 cup sliced mushrooms",
                    "1/2 cup diced bell peppers",
                    "1/4 cup sliced black olives",
                    "1/4 cup sliced red onions",
                    "1/4 cup diced tomatoes",
                    "1/4 cup chopped spinach",
                    "1/4 cup crumbled feta cheese",
                    "1/4 cup grated Parmesan cheese",
                    "1 tbsp olive oil",
                    "1 tsp dried oregano",
                    "1/2 tsp garlic powder",
                    "Salt and pepper to taste"
                ],
                steps: [
                    "Preheat the oven to 425°F (220°C).",
                    "Place the pre-made pizza crust on a baking sheet.",
                    "Spread marinara sauce evenly over the crust, leaving a small border around the edges.",
                    "Sprinkle mozzarella cheese over the sauce.",
                    "Top with mushrooms, bell peppers, black olives, red onions, tomatoes, and spinach.",
                    "Drizzle olive oil over the vegetables.",
                    "Sprinkle with feta cheese, Parmesan cheese, dried oregano, garlic powder, salt, and pepper.",
                    "Bake in the preheated oven for 12-15 minutes, or until the crust is golden brown and the cheese is melted and bubbly.",
                    "Remove from the oven and let cool for a few minutes before slicing.",
                    "Serve hot and enjoy!"
                ]
            },
            {
                ingredients: [
                    "1 pre-made pizza crust",
                    "1/2 cup pesto sauce",
                    "1 cup shredded mozzarella cheese",
                    "1/2 cup cherry tomatoes, halved",
                    "1/2 cup sliced black olives",
                    "1/4 cup sliced red onions",
                    "1/4 cup sliced mushrooms",
                    "1/4 cup chopped artichoke hearts",
                    "1/4 cup crumbled goat cheese",
                    "1 tbsp olive oil",
                    "Salt and pepper to taste"
                ],
                steps: [
                    "Preheat the oven to 425°F (220°C).",
                    "Spread pesto sauce evenly over the pre-made pizza crust.",
                    "Sprinkle shredded mozzarella cheese over the pesto.",
                    "Top with cherry tomatoes, black olives, red onions, mushrooms, and artichoke hearts.",
                    "Drizzle olive oil over the vegetables.",
                    "Season with salt and pepper to taste.",
                    "Bake in the preheated oven for 12-15 minutes, or until the crust is golden brown and the cheese is melted and bubbly.",
                    "Remove from the oven and sprinkle crumbled goat cheese over the hot pizza.",
                    "Slice and serve immediately."
                ]
            }
        ],
       "Tacos": [
            {
                ingredients: [
                    "1 lb ground beef",
                    "1 packet taco seasoning",
                    "12 taco shells",
                    "1 cup shredded lettuce",
                    "1 cup diced tomatoes",
                    "1/2 cup shredded cheddar cheese",
                    "1/4 cup diced red onions",
                    "1/4 cup chopped fresh cilantro",
                    "1/4 cup sour cream",
                    "1/4 cup salsa"
                ],
                steps: [
                    "In a large skillet, cook the ground beef over medium heat until no longer pink.",
                    "Add the taco seasoning packet and water according to the instructions on the packet.",
                    "Simmer for 5-7 minutes, stirring occasionally, until the mixture thickens.",
                    "Meanwhile, heat the taco shells according to the instructions on the package.",
                    "Fill each taco shell with the seasoned ground beef.",
                    "Top with shredded lettuce, diced tomatoes, shredded cheddar cheese, diced red onions, and chopped cilantro.",
                    "Drizzle with sour cream and salsa before serving."
                ]
            },
            {
                ingredients: [
                    "1 lb chicken breast, diced",
                    "1 packet fajita seasoning",
                    "12 flour tortillas",
                    "1 cup shredded cabbage",
                    "1 cup diced mango",
                    "1/2 cup diced red bell pepper",
                    "1/2 cup diced green bell pepper",
                    "1/4 cup chopped fresh cilantro",
                    "1/4 cup diced red onions",
                    "1/4 cup lime juice",
                    "1/4 cup sour cream"
                ],
                steps: [
                    "In a large skillet, cook the diced chicken breast over medium-high heat until fully cooked.",
                    "Add the fajita seasoning packet and water according to the instructions on the packet.",
                    "Simmer for 5-7 minutes, stirring occasionally.",
                    "Warm the flour tortillas in a dry skillet or microwave.",
                    "Fill each tortilla with the cooked chicken mixture.",
                    "Top with shredded cabbage, diced mango, diced bell peppers, chopped cilantro, and diced red onions.",
                    "Drizzle with lime juice and sour cream before serving."
                ]
            },
            {
                ingredients: [
                    "1 lb shrimp, peeled and deveined",
                    "2 tbsp taco seasoning",
                    "12 corn tortillas",
                    "1 cup shredded lettuce",
                    "1 cup diced pineapple",
                    "1/2 cup diced red bell pepper",
                    "1/2 cup diced green bell pepper",
                    "1/4 cup chopped fresh cilantro",
                    "1/4 cup diced red onions",
                    "1/4 cup lime juice",
                    "1/4 cup salsa verde"
                ],
                steps: [
                    "In a bowl, toss the shrimp with taco seasoning until evenly coated.",
                    "In a large skillet, cook the seasoned shrimp over medium-high heat until pink and cooked through.",
                    "Warm the corn tortillas in a dry skillet or microwave.",
                    "Fill each tortilla with the cooked shrimp.",
                    "Top with shredded lettuce, diced pineapple, diced bell peppers, chopped cilantro, and diced red onions.",
                    "Drizzle with lime juice and salsa verde before serving."
                ]
            }
        ],
       "Sushi": [
            {
                name: "California Roll",
                ingredients: [
                    "1 cup sushi rice",
                    "2 nori seaweed sheets",
                    "1/2 avocado, sliced",
                    "1/2 cucumber, julienned",
                    "4 imitation crab sticks, shredded",
                    "Soy sauce, for dipping",
                    "Wasabi, for dipping"
                ],
                steps: [
                    "Prepare sushi rice according to package instructions and let it cool.",
                    "Place a nori seaweed sheet on a bamboo sushi mat.",
                    "Spread a thin layer of sushi rice evenly over the nori, leaving a 1-inch border at the top edge.",
                    "Arrange avocado slices, cucumber strips, and shredded crab sticks along the center of the rice.",
                    "Starting from the bottom edge, tightly roll the sushi using the bamboo mat, pressing gently to seal.",
                    "Slice the roll into bite-sized pieces using a sharp knife dipped in water.",
                    "Serve with soy sauce and wasabi for dipping."
                ]
            },
            {
                name: "Spicy Tuna Roll",
                ingredients: [
                    "1 cup sushi rice",
                    "2 nori seaweed sheets",
                    "1/2 lb sushi-grade tuna, diced",
                    "1/4 cup mayonnaise",
                    "1 tbsp sriracha sauce",
                    "1/2 avocado, sliced",
                    "Soy sauce, for dipping",
                    "Pickled ginger, for serving"
                ],
                steps: [
                    "Prepare sushi rice according to package instructions and let it cool.",
                    "In a small bowl, mix diced tuna with mayonnaise and sriracha sauce.",
                    "Place a nori seaweed sheet on a bamboo sushi mat.",
                    "Spread a thin layer of sushi rice evenly over the nori, leaving a 1-inch border at the top edge.",
                    "Spread spicy tuna mixture evenly over the rice.",
                    "Arrange avocado slices along the center of the tuna.",
                    "Starting from the bottom edge, tightly roll the sushi using the bamboo mat, pressing gently to seal.",
                    "Slice the roll into bite-sized pieces using a sharp knife dipped in water.",
                    "Serve with soy sauce and pickled ginger."
                ]
            },
            {
                name: "Vegetable Roll",
                ingredients: [
                    "1 cup sushi rice",
                    "2 nori seaweed sheets",
                    "1/2 cucumber, julienned",
                    "1/2 carrot, julienned",
                    "1/2 avocado, sliced",
                    "1/4 cup cream cheese, sliced",
                    "Soy sauce, for dipping",
                    "Wasabi, for dipping"
                ],
                steps: [
                    "Prepare sushi rice according to package instructions and let it cool.",
                    "Place a nori seaweed sheet on a bamboo sushi mat.",
                    "Spread a thin layer of sushi rice evenly over the nori, leaving a 1-inch border at the top edge.",
                    "Arrange cucumber, carrot, avocado slices, and cream cheese along the center of the rice.",
                    "Starting from the bottom edge, tightly roll the sushi using the bamboo mat, pressing gently to seal.",
                    "Slice the roll into bite-sized pieces using a sharp knife dipped in water.",
                    "Serve with soy sauce and wasabi for dipping."
                ]
            }
        ],
       "Pancakes": [
            {
                name: "Classic Pancakes",
                ingredients: [
                    "1 cup all-purpose flour",
                    "2 tbsp granulated sugar",
                    "1 tsp baking powder",
                    "1/2 tsp baking soda",
                    "1/4 tsp salt",
                    "1 cup buttermilk",
                    "1 large egg",
                    "2 tbsp unsalted butter, melted",
                    "1 tsp vanilla extract",
                    "Butter or oil for cooking",
                    "Maple syrup for serving"
                ],
                steps: [
                    "In a large mixing bowl, whisk together flour, sugar, baking powder, baking soda, and salt.",
                    "In another bowl, whisk together buttermilk, egg, melted butter, and vanilla extract.",
                    "Pour the wet ingredients into the dry ingredients and stir until just combined. Do not overmix; the batter may be slightly lumpy.",
                    "Heat a non-stick skillet or griddle over medium heat and lightly grease with butter or oil.",
                    "Pour 1/4 cup of batter onto the skillet for each pancake.",
                    "Cook until bubbles form on the surface, then flip and cook until golden brown on both sides.",
                    "Serve warm with maple syrup."
                ]
            },
            {
                name: "Blueberry Pancakes",
                ingredients: [
                    "1 cup all-purpose flour",
                    "2 tbsp granulated sugar",
                    "1 tsp baking powder",
                    "1/2 tsp baking soda",
                    "1/4 tsp salt",
                    "1 cup buttermilk",
                    "1 large egg",
                    "2 tbsp unsalted butter, melted",
                    "1 tsp vanilla extract",
                    "1/2 cup fresh blueberries",
                    "Butter or oil for cooking",
                    "Maple syrup for serving"
                ],
                steps: [
                    "Follow the same instructions as for Classic Pancakes, but fold fresh blueberries into the batter just before cooking.",
                    "Cook as directed until golden brown on both sides.",
                    "Serve warm with maple syrup."
                ]
            },
            {
                name: "Chocolate Chip Pancakes",
                ingredients: [
                    "1 cup all-purpose flour",
                    "2 tbsp granulated sugar",
                    "1 tsp baking powder",
                    "1/2 tsp baking soda",
                    "1/4 tsp salt",
                    "1 cup buttermilk",
                    "1 large egg",
                    "2 tbsp unsalted butter, melted",
                    "1 tsp vanilla extract",
                    "1/2 cup chocolate chips",
                    "Butter or oil for cooking",
                    "Maple syrup for serving"
                ],
                steps: [
                    "Follow the same instructions as for Classic Pancakes, but fold chocolate chips into the batter just before cooking.",
                    "Cook as directed until golden brown on both sides.",
                    "Serve warm with maple syrup."
                ]
            }
        ],
        "Grilled Cheese Sandwich": [
            {
                name: "Classic Grilled Cheese",
                ingredients: [
                    "2 slices of bread",
                    "2 slices of cheddar cheese",
                    "1 tbsp butter"
                ],
                steps: [
                    "Place a slice of cheese between two slices of bread to form a sandwich.",
                    "Heat a skillet over medium-low heat and add butter.",
                    "Once the butter has melted and the skillet is hot, place the sandwich in the skillet.",
                    "Cook until the bread is golden brown and crispy, and the cheese has melted, about 2-3 minutes per side.",
                    "Remove from the skillet, slice, and serve immediately."
                ]
            },
            {
                name: "Tomato and Basil Grilled Cheese",
                ingredients: [
                    "2 slices of bread",
                    "2 slices of cheddar cheese",
                    "1 small tomato, thinly sliced",
                    "A few fresh basil leaves",
                    "1 tbsp butter"
                ],
                steps: [
                    "Assemble the sandwich by layering cheese, tomato slices, and basil leaves between two slices of bread.",
                    "Heat a skillet over medium-low heat and add butter.",
                    "Once the butter has melted and the skillet is hot, place the sandwich in the skillet.",
                    "Cook until the bread is golden brown and crispy, and the cheese has melted, about 2-3 minutes per side.",
                    "Remove from the skillet, slice, and serve immediately."
                ]
            },
            {
                name: "Bacon and Avocado Grilled Cheese",
                ingredients: [
                    "2 slices of bread",
                    "2 slices of cheddar cheese",
                    "2 slices of cooked bacon",
                    "1/2 avocado, sliced",
                    "1 tbsp butter"
                ],
                steps: [
                    "Assemble the sandwich by layering cheese, bacon slices, and avocado slices between two slices of bread.",
                    "Heat a skillet over medium-low heat and add butter.",
                    "Once the butter has melted and the skillet is hot, place the sandwich in the skillet.",
                    "Cook until the bread is golden brown and crispy, and the cheese has melted, about 2-3 minutes per side.",
                    "Remove from the skillet, slice, and serve immediately."
                ]
            }
        ],
       "French Onion Soup": [
            {
                name: "Classic French Onion Soup",
                ingredients: [
                    "4 large onions, thinly sliced",
                    "4 cups beef broth",
                    "2 tbsp butter",
                    "2 tbsp olive oil",
                    "1 tsp sugar",
                    "1/4 cup dry white wine (optional)",
                    "Salt and pepper to taste",
                    "4 slices of French baguette",
                    "1 cup shredded Gruyere cheese"
                ],
                steps: [
                    "In a large pot, melt butter with olive oil over medium heat.",
                    "Add sliced onions and sugar. Cook, stirring frequently, until onions are caramelized and golden brown, about 30-40 minutes.",
                    "Deglaze the pot with white wine, if using, and cook until the wine has evaporated.",
                    "Add beef broth to the pot. Bring to a simmer and cook for another 15-20 minutes.",
                    "Season with salt and pepper to taste.",
                    "Preheat the broiler. Ladle the soup into oven-safe bowls. Top each bowl with a slice of French baguette and shredded Gruyere cheese.",
                    "Place the bowls under the broiler until the cheese is melted and bubbly, about 2-3 minutes.",
                    "Serve hot."
                ]
            },
            {
                name: "Vegetarian French Onion Soup",
                ingredients: [
                    "4 large onions, thinly sliced",
                    "4 cups vegetable broth",
                    "2 tbsp butter",
                    "2 tbsp olive oil",
                    "1 tsp sugar",
                    "1/4 cup dry white wine (optional)",
                    "Salt and pepper to taste",
                    "4 slices of French baguette",
                    "1 cup shredded Swiss cheese"
                ],
                steps: [
                    "In a large pot, melt butter with olive oil over medium heat.",
                    "Add sliced onions and sugar. Cook, stirring frequently, until onions are caramelized and golden brown, about 30-40 minutes.",
                    "Deglaze the pot with white wine, if using, and cook until the wine has evaporated.",
                    "Add vegetable broth to the pot. Bring to a simmer and cook for another 15-20 minutes.",
                    "Season with salt and pepper to taste.",
                    "Preheat the broiler. Ladle the soup into oven-safe bowls. Top each bowl with a slice of French baguette and shredded Swiss cheese.",
                    "Place the bowls under the broiler until the cheese is melted and bubbly, about 2-3 minutes.",
                    "Serve hot."
                ]
            }
        ],
       "Apple Pie": [
            {
                name: "Classic Apple Pie",
                ingredients: [
                    "6 cups sliced apples (Granny Smith or your preferred variety)",
                    "3/4 cup white sugar",
                    "1/4 cup brown sugar",
                    "1 tsp ground cinnamon",
                    "1/4 tsp ground nutmeg",
                    "2 tbsp all-purpose flour",
                    "1 tbsp lemon juice",
                    "2 pie crusts (homemade or store-bought)"
                ],
                steps: [
                    "Preheat the oven to 425°F (220°C).",
                    "In a large bowl, combine sliced apples, white sugar, brown sugar, cinnamon, nutmeg, flour, and lemon juice. Mix well.",
                    "Line a 9-inch pie dish with one pie crust. Pour the apple filling into the crust.",
                    "Cover the filling with the second pie crust. Seal and flute the edges.",
                    "Cut several slits in the top crust to allow steam to escape.",
                    "Bake in the preheated oven for 45-50 minutes, or until the crust is golden brown and the filling is bubbly.",
                    "Allow the pie to cool before slicing. Serve warm with ice cream, if desired."
                ]
            },
            {
                name: "Dutch Apple Pie",
                ingredients: [
                    "6 cups sliced apples (Granny Smith or your preferred variety)",
                    "3/4 cup white sugar",
                    "1/4 cup brown sugar",
                    "1 tsp ground cinnamon",
                    "1/4 tsp ground nutmeg",
                    "2 tbsp all-purpose flour",
                    "1 tbsp lemon juice",
                    "1 cup all-purpose flour",
                    "1/2 cup cold butter, cubed",
                    "1/2 cup white sugar",
                    "1/2 cup brown sugar"
                ],
                steps: [
                    "Preheat the oven to 375°F (190°C).",
                    "In a large bowl, combine sliced apples, white sugar, brown sugar, cinnamon, nutmeg, flour, and lemon juice. Mix well.",
                    "Pour the apple filling into a 9-inch pie dish.",
                    "In a separate bowl, combine 1 cup flour, cold cubed butter, white sugar, and brown sugar. Mix until crumbly.",
                    "Sprinkle the crumb mixture evenly over the apple filling.",
                    "Bake in the preheated oven for 45-50 minutes, or until the topping is golden brown and the filling is bubbly.",
                    "Allow the pie to cool before slicing. Serve warm with whipped cream or vanilla ice cream."
                ]
            }
        ],
       "BBQ Ribs": [
            {
                name: "Smoked BBQ Ribs",
                ingredients: [
                    "2 racks of pork baby back ribs",
                    "1/4 cup brown sugar",
                    "2 tbsp paprika",
                    "2 tbsp garlic powder",
                    "2 tbsp onion powder",
                    "2 tbsp chili powder",
                    "2 tbsp salt",
                    "1 tbsp black pepper",
                    "1 tbsp cayenne pepper (optional)",
                    "2 cups BBQ sauce"
                ],
                steps: [
                    "Preheat your smoker to 225°F (107°C) using hickory or apple wood.",
                    "Remove the membrane from the back of the ribs.",
                    "In a bowl, mix brown sugar, paprika, garlic powder, onion powder, chili powder, salt, black pepper, and cayenne pepper.",
                    "Rub the seasoning mixture generously over both sides of the ribs.",
                    "Place the ribs in the smoker and cook for 4-5 hours, or until tender. Maintain a steady temperature throughout the smoking process.",
                    "During the last 30 minutes of cooking, brush the ribs with BBQ sauce on both sides.",
                    "Once done, remove the ribs from the smoker and let them rest for 10 minutes before slicing and serving."
                ]
            },
            {
                name: "Oven-Baked BBQ Ribs",
                ingredients: [
                    "2 racks of pork baby back ribs",
                    "1/4 cup brown sugar",
                    "2 tbsp paprika",
                    "2 tbsp garlic powder",
                    "2 tbsp onion powder",
                    "2 tbsp chili powder",
                    "2 tbsp salt",
                    "1 tbsp black pepper",
                    "1 tbsp cayenne pepper (optional)",
                    "2 cups BBQ sauce"
                ],
                steps: [
                    "Preheat your oven to 275°F (135°C).",
                    "Remove the membrane from the back of the ribs.",
                    "In a bowl, mix brown sugar, paprika, garlic powder, onion powder, chili powder, salt, black pepper, and cayenne pepper.",
                    "Rub the seasoning mixture generously over both sides of the ribs.",
                    "Wrap each rack of ribs tightly in aluminum foil.",
                    "Place the foil-wrapped ribs on a baking sheet and bake in the preheated oven for 2.5-3 hours, or until tender.",
                    "Remove the ribs from the oven and carefully unwrap them. Brush with BBQ sauce on both sides.",
                    "Turn on the broiler and place the ribs under the broiler for 3-4 minutes, or until the sauce is caramelized.",
                    "Let the ribs rest for a few minutes before slicing and serving."
                ]
            },
            {
                name: "Grilled BBQ Ribs",
                ingredients: [
                    "2 racks of pork baby back ribs",
                    "1/4 cup brown sugar",
                    "2 tbsp paprika",
                    "2 tbsp garlic powder",
                    "2 tbsp onion powder",
                    "2 tbsp chili powder",
                    "2 tbsp salt",
                    "1 tbsp black pepper",
                    "1 tbsp cayenne pepper (optional)",
                    "2 cups BBQ sauce"
                ],
                steps: [
                    "Preheat your grill to medium-high heat.",
                    "Remove the membrane from the back of the ribs.",
                    "In a bowl, mix brown sugar, paprika, garlic powder, onion powder, chili powder, salt, black pepper, and cayenne pepper.",
                    "Rub the seasoning mixture generously over both sides of the ribs.",
                    "Place the ribs on the grill and cook for 10-12 minutes per side, or until cooked through.",
                    "During the last 5 minutes of cooking, brush the ribs with BBQ sauce on both sides.",
                    "Once done, remove the ribs from the grill and let them rest for a few minutes before slicing and serving."
                ]
            }
        ],
       "Pad Thai": [
            {
                name: "Classic Pad Thai",
                ingredients: [
                    "200g rice noodles",
                    "2 tbsp tamarind paste",
                    "3 tbsp fish sauce",
                    "2 tbsp palm sugar",
                    "2 tbsp vegetable oil",
                    "200g tofu, diced",
                    "2 cloves garlic, minced",
                    "2 eggs, beaten",
                    "200g shrimp, peeled and deveined",
                    "1 cup bean sprouts",
                    "4 green onions, chopped",
                    "1/4 cup crushed peanuts",
                    "Lime wedges, for serving",
                    "Fresh cilantro, for garnish"
                ],
                steps: [
                    "Soak the rice noodles in warm water for 30 minutes, then drain and set aside.",
                    "In a small bowl, mix tamarind paste, fish sauce, and palm sugar to make the sauce.",
                    "Heat vegetable oil in a wok over medium-high heat. Add tofu and stir-fry until golden brown. Remove and set aside.",
                    "In the same wok, add garlic and cook until fragrant. Push garlic to the side and pour beaten eggs into the wok. Scramble until cooked.",
                    "Add shrimp to the wok and cook until pink and opaque.",
                    "Add drained noodles and prepared sauce to the wok. Toss until noodles are well coated and heated through.",
                    "Stir in bean sprouts and green onions. Cook for another minute.",
                    "Serve Pad Thai hot, garnished with crushed peanuts, lime wedges, and fresh cilantro."
                ]
            },
            {
                name: "Vegetarian Pad Thai",
                ingredients: [
                    "200g rice noodles",
                    "2 tbsp tamarind paste",
                    "3 tbsp soy sauce",
                    "2 tbsp palm sugar",
                    "2 tbsp vegetable oil",
                    "200g firm tofu, diced",
                    "2 cloves garlic, minced",
                    "2 eggs, beaten",
                    "1 cup broccoli florets",
                    "1 bell pepper, thinly sliced",
                    "1 carrot, julienned",
                    "1 cup bean sprouts",
                    "4 green onions, chopped",
                    "1/4 cup crushed peanuts",
                    "Lime wedges, for serving",
                    "Fresh cilantro, for garnish"
                ],
                steps: [
                    "Soak the rice noodles in warm water for 30 minutes, then drain and set aside.",
                    "In a small bowl, mix tamarind paste, soy sauce, and palm sugar to make the sauce.",
                    "Heat vegetable oil in a wok over medium-high heat. Add tofu and stir-fry until golden brown. Remove and set aside.",
                    "In the same wok, add garlic and cook until fragrant. Push garlic to the side and pour beaten eggs into the wok. Scramble until cooked.",
                    "Add broccoli, bell pepper, and carrot to the wok. Stir-fry until vegetables are tender-crisp.",
                    "Add drained noodles and prepared sauce to the wok. Toss until noodles are well coated and heated through.",
                    "Stir in bean sprouts and green onions. Cook for another minute.",
                    "Serve Vegetarian Pad Thai hot, garnished with crushed peanuts, lime wedges, and fresh cilantro."
                ]
            },
            {
                name: "Shrimp Pad Thai",
                ingredients: [
                    "200g rice noodles",
                    "2 tbsp tamarind paste",
                    "3 tbsp fish sauce",
                    "2 tbsp palm sugar",
                    "2 tbsp vegetable oil",
                    "200g shrimp, peeled and deveined",
                    "2 cloves garlic, minced",
                    "2 eggs, beaten",
                    "1 cup bean sprouts",
                    "4 green onions, chopped",
                    "1/4 cup crushed peanuts",
                    "Lime wedges, for serving",
                    "Fresh cilantro, for garnish"
                ],
                steps: [
                    "Soak the rice noodles in warm water for 30 minutes, then drain and set aside.",
                    "In a small bowl, mix tamarind paste, fish sauce, and palm sugar to make the sauce.",
                    "Heat vegetable oil in a wok over medium-high heat. Add shrimp and cook until pink and opaque. Remove and set aside.",
                    "In the same wok, add garlic and cook until fragrant. Push garlic to the side and pour beaten eggs into the wok. Scramble until cooked.",
                    "Add drained noodles and prepared sauce to the wok. Toss until noodles are well coated and heated through.",
                    "Stir in cooked shrimp, bean sprouts, and green onions. Cook for another minute.",
                    "Serve Shrimp Pad Thai hot, garnished with crushed peanuts, lime wedges, and fresh cilantro."
                ]
            }
        ],
        "Chicken Alfredo": [
            {
                name: "Classic Chicken Alfredo",
                ingredients: [
                    "250g fettuccine pasta",
                    "2 chicken breasts, thinly sliced",
                    "2 tbsp olive oil",
                    "4 cloves garlic, minced",
                    "1 cup heavy cream",
                    "1 cup grated Parmesan cheese",
                    "Salt and pepper to taste",
                    "Fresh parsley, chopped, for garnish"
                ],
                steps: [
                    "Cook fettuccine pasta according to package instructions. Drain and set aside.",
                    "Season chicken breasts with salt and pepper.",
                    "In a large skillet, heat olive oil over medium heat. Add chicken slices and cook until browned and cooked through. Remove from skillet and set aside.",
                    "In the same skillet, add minced garlic and cook until fragrant.",
                    "Pour heavy cream into the skillet and bring to a simmer. Stir in grated Parmesan cheese until melted and smooth.",
                    "Add cooked fettuccine pasta to the skillet and toss to coat in the Alfredo sauce.",
                    "Return cooked chicken to the skillet and stir to combine. Cook for a few more minutes until heated through.",
                    "Garnish Chicken Alfredo with chopped fresh parsley before serving."
                ]
            },
            {
                name: "Broccoli Chicken Alfredo",
                ingredients: [
                    "250g fettuccine pasta",
                    "2 chicken breasts, thinly sliced",
                    "2 tbsp olive oil",
                    "4 cloves garlic, minced",
                    "1 cup heavy cream",
                    "1 cup grated Parmesan cheese",
                    "1 cup broccoli florets, blanched",
                    "Salt and pepper to taste",
                    "Fresh parsley, chopped, for garnish"
                ],
                steps: [
                    "Cook fettuccine pasta according to package instructions. Drain and set aside.",
                    "Season chicken breasts with salt and pepper.",
                    "In a large skillet, heat olive oil over medium heat. Add chicken slices and cook until browned and cooked through. Remove from skillet and set aside.",
                    "In the same skillet, add minced garlic and cook until fragrant.",
                    "Pour heavy cream into the skillet and bring to a simmer. Stir in grated Parmesan cheese until melted and smooth.",
                    "Add blanched broccoli florets and cooked fettuccine pasta to the skillet. Toss to coat in the Alfredo sauce.",
                    "Return cooked chicken to the skillet and stir to combine. Cook for a few more minutes until heated through.",
                    "Garnish Chicken Alfredo with chopped fresh parsley before serving."
                ]
            },
            {
                name: "Spinach Chicken Alfredo",
                ingredients: [
                    "250g fettuccine pasta",
                    "2 chicken breasts, thinly sliced",
                    "2 tbsp olive oil",
                    "4 cloves garlic, minced",
                    "1 cup heavy cream",
                    "1 cup grated Parmesan cheese",
                    "2 cups fresh spinach leaves",
                    "Salt and pepper to taste",
                    "Fresh parsley, chopped, for garnish"
                ],
                steps: [
                    "Cook fettuccine pasta according to package instructions. Drain and set aside.",
                    "Season chicken breasts with salt and pepper.",
                    "In a large skillet, heat olive oil over medium heat. Add chicken slices and cook until browned and cooked through. Remove from skillet and set aside.",
                    "In the same skillet, add minced garlic and cook until fragrant.",
                    "Pour heavy cream into the skillet and bring to a simmer. Stir in grated Parmesan cheese until melted and smooth.",
                    "Add fresh spinach leaves and cooked fettuccine pasta to the skillet. Toss to coat in the Alfredo sauce.",
                    "Return cooked chicken to the skillet and stir to combine. Cook for a few more minutes until heated through.",
                    "Garnish Chicken Alfredo with chopped fresh parsley before serving."
                ]
            }
        ],
       "Lasagna": [
            {
                name: "Classic Beef Lasagna",
                ingredients: [
                    "9 lasagna noodles",
                    "500g ground beef",
                    "1 onion, finely chopped",
                    "3 cloves garlic, minced",
                    "800g canned crushed tomatoes",
                    "2 cups shredded mozzarella cheese",
                    "1 cup grated Parmesan cheese",
                    "2 tbsp olive oil",
                    "1 tsp dried oregano",
                    "1 tsp dried basil",
                    "Salt and pepper to taste"
                ],
                steps: [
                    "Preheat oven to 180°C (350°F).",
                    "Cook lasagna noodles according to package instructions. Drain and set aside.",
                    "In a large skillet, heat olive oil over medium heat. Add chopped onion and minced garlic, and sauté until translucent.",
                    "Add ground beef and cook until browned. Drain excess fat.",
                    "Stir in crushed tomatoes, dried oregano, dried basil, salt, and pepper. Simmer for 10 minutes.",
                    "Spread a layer of meat sauce on the bottom of a baking dish. Arrange a layer of cooked lasagna noodles on top.",
                    "Repeat layers of meat sauce and noodles. Top with shredded mozzarella and grated Parmesan cheese.",
                    "Cover with foil and bake in the preheated oven for 30 minutes.",
                    "Remove foil and bake for an additional 10 minutes, or until cheese is bubbly and golden brown.",
                    "Let lasagna cool for a few minutes before serving."
                ]
            },
            {
                name: "Vegetarian Lasagna",
                ingredients: [
                    "9 lasagna noodles",
                    "2 cups marinara sauce",
                    "2 cups ricotta cheese",
                    "2 cups shredded mozzarella cheese",
                    "1 cup grated Parmesan cheese",
                    "2 cups fresh spinach leaves",
                    "1 zucchini, thinly sliced",
                    "1 bell pepper, diced",
                    "1 onion, diced",
                    "2 cloves garlic, minced",
                    "2 tbsp olive oil",
                    "1 tsp dried oregano",
                    "1 tsp dried basil",
                    "Salt and pepper to taste"
                ],
                steps: [
                    "Preheat oven to 180°C (350°F).",
                    "Cook lasagna noodles according to package instructions. Drain and set aside.",
                    "In a large skillet, heat olive oil over medium heat. Add diced onion, minced garlic, sliced zucchini, diced bell pepper, and fresh spinach leaves. Sauté until vegetables are softened.",
                    "Season with dried oregano, dried basil, salt, and pepper. Remove from heat.",
                    "Spread a layer of marinara sauce on the bottom of a baking dish. Arrange a layer of cooked lasagna noodles on top.",
                    "Spread a layer of ricotta cheese over the noodles, followed by a layer of sautéed vegetables.",
                    "Repeat layers of marinara sauce, noodles, ricotta cheese, and vegetables. Top with shredded mozzarella and grated Parmesan cheese.",
                    "Cover with foil and bake in the preheated oven for 30 minutes.",
                    "Remove foil and bake for an additional 10 minutes, or until cheese is bubbly and golden brown.",
                    "Let lasagna cool for a few minutes before serving."
                ]
            },
            {
                name: "Chicken Alfredo Lasagna",
                ingredients: [
                    "9 lasagna noodles",
                    "2 cups Alfredo sauce",
                    "2 cups cooked chicken, shredded",
                    "2 cups shredded mozzarella cheese",
                    "1 cup grated Parmesan cheese",
                    "2 cups baby spinach leaves",
                    "2 cloves garlic, minced",
                    "2 tbsp olive oil",
                    "Salt and pepper to taste"
                ],
                steps: [
                    "Preheat oven to 180°C (350°F).",
                    "Cook lasagna noodles according to package instructions. Drain and set aside.",
                    "In a large skillet, heat olive oil over medium heat. Add minced garlic and sauté until fragrant.",
                    "Add baby spinach leaves and cook until wilted. Remove from heat.",
                    "Spread a layer of Alfredo sauce on the bottom of a baking dish. Arrange a layer of cooked lasagna noodles on top.",
                    "Spread a layer of cooked chicken over the noodles, followed by a layer of sautéed spinach.",
                    "Repeat layers of Alfredo sauce, noodles, chicken, and spinach. Top with shredded mozzarella and grated Parmesan cheese.",
                    "Cover with foil and bake in the preheated oven for 30 minutes.",
                    "Remove foil and bake for an additional 10 minutes, or until cheese is bubbly and golden brown.",
                    "Let lasagna cool for a few minutes before serving."
                ]
            }
        ],
        "Chocolate Cake": [
            {
                name: "Classic Chocolate Cake",
                ingredients: [
                    "1 and 3/4 cups all-purpose flour",
                    "3/4 cup unsweetened cocoa powder",
                    "2 cups granulated sugar",
                    "1 and 1/2 teaspoons baking powder",
                    "1 and 1/2 teaspoons baking soda",
                    "1 teaspoon salt",
                    "2 large eggs",
                    "1 cup whole milk",
                    "1/2 cup vegetable oil",
                    "2 teaspoons vanilla extract",
                    "1 cup boiling water"
                ],
                steps: [
                    "Preheat oven to 180°C (350°F). Grease and flour two 9-inch round cake pans.",
                    "In a large mixing bowl, sift together flour, cocoa powder, sugar, baking powder, baking soda, and salt.",
                    "Add eggs, milk, oil, and vanilla to the dry ingredients and beat on medium speed for 2 minutes.",
                    "Stir in boiling water until well combined. The batter will be thin.",
                    "Pour the batter evenly into the prepared pans.",
                    "Bake in the preheated oven for 30 to 35 minutes, or until a toothpick inserted into the center comes out clean.",
                    "Remove cakes from oven and let them cool in the pans for 10 minutes.",
                    "Carefully remove cakes from pans and transfer them to a wire rack to cool completely.",
                    "Once cooled, frost with your favorite chocolate frosting."
                ]
            },
            {
                name: "Flourless Chocolate Cake",
                ingredients: [
                    "200g dark chocolate, chopped",
                    "3/4 cup unsalted butter",
                    "1 cup granulated sugar",
                    "1/2 cup cocoa powder",
                    "3 large eggs",
                    "1 teaspoon vanilla extract",
                    "1/4 teaspoon salt",
                    "Whipped cream and fresh berries for serving (optional)"
                ],
                steps: [
                    "Preheat oven to 180°C (350°F). Grease a 9-inch round cake pan and line the bottom with parchment paper.",
                    "In a heatproof bowl, melt the chocolate and butter together over a double boiler or in the microwave, stirring until smooth.",
                    "Whisk in the sugar, cocoa powder, eggs, vanilla extract, and salt until well combined.",
                    "Pour the batter into the prepared cake pan.",
                    "Bake in the preheated oven for 25 to 30 minutes, or until the edges are set and the center is slightly soft but not wobbly.",
                    "Remove the cake from the oven and let it cool completely in the pan.",
                    "Once cooled, remove the cake from the pan and transfer it to a serving plate.",
                    "Slice and serve with whipped cream and fresh berries, if desired."
                ]
            },
            {
                name: "Vegan Chocolate Cake",
                ingredients: [
                    "1 and 1/2 cups all-purpose flour",
                    "1 cup granulated sugar",
                    "1/4 cup unsweetened cocoa powder",
                    "1 teaspoon baking soda",
                    "1/2 teaspoon salt",
                    "1 cup brewed coffee, cooled",
                    "1/3 cup vegetable oil",
                    "1 tablespoon white vinegar",
                    "1 teaspoon vanilla extract",
                    "Vegan chocolate frosting"
                ],
                steps: [
                    "Preheat oven to 180°C (350°F). Grease and flour an 8-inch square or round cake pan.",
                    "In a large mixing bowl, whisk together flour, sugar, cocoa powder, baking soda, and salt.",
                    "Add coffee, oil, vinegar, and vanilla extract to the dry ingredients and mix until smooth.",
                    "Pour the batter into the prepared cake pan.",
                    "Bake in the preheated oven for 30 to 35 minutes, or until a toothpick inserted into the center comes out clean.",
                    "Remove the cake from the oven and let it cool completely in the pan.",
                    "Once cooled, frost with vegan chocolate frosting."
                ]
            }
        ],
        "Tiramisu": [
            {
                name: "Classic Tiramisu",
                ingredients: [
                    "6 large egg yolks",
                    "3/4 cup granulated sugar",
                    "1 cup mascarpone cheese, softened",
                    "1 and 1/2 cups heavy cream",
                    "1 and 1/2 cups strong brewed coffee, cooled",
                    "1/2 cup coffee liqueur (such as Kahlua)",
                    "24 to 30 ladyfingers (savoiardi biscuits)",
                    "Unsweetened cocoa powder, for dusting"
                ],
                steps: [
                    "In a heatproof bowl, whisk together egg yolks and sugar. Place the bowl over a pot of simmering water, making sure the bottom of the bowl does not touch the water. Whisk constantly until the mixture thickens and becomes pale yellow.",
                    "Remove the bowl from heat and whisk in the mascarpone cheese until smooth. Set aside.",
                    "In another bowl, whip the heavy cream until stiff peaks form. Gently fold the whipped cream into the mascarpone mixture until well combined.",
                    "In a shallow dish, combine the brewed coffee and coffee liqueur. Dip each ladyfinger into the coffee mixture briefly, making sure not to soak them too long.",
                    "Arrange a layer of soaked ladyfingers in the bottom of a 9x13 inch dish. Spread half of the mascarpone mixture over the ladyfingers. Repeat with another layer of soaked ladyfingers and the remaining mascarpone mixture.",
                    "Cover and refrigerate the tiramisu for at least 4 hours, or overnight, to allow the flavors to meld.",
                    "Before serving, dust the top of the tiramisu with unsweetened cocoa powder.",
                    "Slice and serve chilled. Enjoy!"
                ]
            },
            {
                name: "Berry Tiramisu",
                ingredients: [
                    "6 large egg yolks",
                    "3/4 cup granulated sugar",
                    "1 cup mascarpone cheese, softened",
                    "1 and 1/2 cups heavy cream",
                    "1 and 1/2 cups strong brewed coffee, cooled",
                    "1/2 cup coffee liqueur (such as Kahlua)",
                    "24 to 30 ladyfingers (savoiardi biscuits)",
                    "1 cup mixed berries (such as strawberries, raspberries, and blueberries)",
                    "Unsweetened cocoa powder, for dusting"
                ],
                steps: [
                    "Prepare the tiramisu following the steps for Classic Tiramisu, substituting the coffee liqueur with berry liqueur or omitting it entirely if preferred.",
                    "After assembling the layers of ladyfingers and mascarpone mixture, scatter the mixed berries evenly over the top.",
                    "Cover and refrigerate the tiramisu as usual.",
                    "Before serving, dust the top with unsweetened cocoa powder and garnish with additional berries, if desired.",
                    "Slice and serve chilled. Enjoy the fruity twist on this classic dessert!"
                ]
            },
            {
                name: "Chocolate Tiramisu",
                ingredients: [
                    "6 large egg yolks",
                    "3/4 cup granulated sugar",
                    "1 cup mascarpone cheese, softened",
                    "1 and 1/2 cups heavy cream",
                    "1 and 1/2 cups strong brewed coffee, cooled",
                    "1/2 cup coffee liqueur (such as Kahlua)",
                    "24 to 30 ladyfingers (savoiardi biscuits)",
                    "1 cup semisweet chocolate chips or grated dark chocolate",
                    "Unsweetened cocoa powder, for dusting"
                ],
                steps: [
                    "Prepare the tiramisu following the steps for Classic Tiramisu.",
                    "After assembling the layers of ladyfingers and mascarpone mixture, sprinkle half of the chocolate chips or grated chocolate over the top.",
                    "Repeat with another layer of ladyfingers and mascarpone mixture, and finish with the remaining chocolate chips or grated chocolate on top.",
                    "Cover and refrigerate the tiramisu as usual.",
                    "Before serving, dust the top with unsweetened cocoa powder for extra chocolatey goodness.",
                    "Slice and serve chilled. Enjoy the rich and indulgent chocolate version of tiramisu!"
                ]
            }
        ],
        "Bruschetta": [
            {
                name: "Classic Tomato Bruschetta",
                ingredients: [
                    "4 to 5 ripe tomatoes, diced",
                    "2 cloves garlic, minced",
                    "1/4 cup fresh basil leaves, chopped",
                    "2 tablespoons extra virgin olive oil",
                    "1 tablespoon balsamic vinegar",
                    "Salt and pepper to taste",
                    "1 baguette, sliced",
                    "Extra virgin olive oil, for brushing",
                    "1 clove garlic, peeled (for rubbing on the bread)"
                ],
                steps: [
                    "In a bowl, combine the diced tomatoes, minced garlic, chopped basil, extra virgin olive oil, and balsamic vinegar. Season with salt and pepper to taste. Mix well and set aside to marinate for at least 15 minutes.",
                    "Preheat the oven to 375°F (190°C).",
                    "Place the baguette slices on a baking sheet. Brush each slice lightly with extra virgin olive oil on one side. Toast in the preheated oven for 5-7 minutes, or until golden brown and crispy.",
                    "Remove the toasted baguette slices from the oven. Rub the peeled garlic clove over one side of each slice for extra flavor.",
                    "Top each toasted baguette slice with the tomato mixture, spreading it evenly.",
                    "Serve immediately as an appetizer or snack. Enjoy the freshness of classic tomato bruschetta!"
                ]
            },
            {
                name: "Mushroom and Goat Cheese Bruschetta",
                ingredients: [
                    "2 cups mushrooms (such as cremini or button mushrooms), sliced",
                    "2 cloves garlic, minced",
                    "2 tablespoons olive oil",
                    "Salt and pepper to taste",
                    "4 ounces goat cheese",
                    "1 baguette, sliced",
                    "Extra virgin olive oil, for brushing",
                    "Fresh parsley, chopped (for garnish)"
                ],
                steps: [
                    "Heat olive oil in a skillet over medium heat. Add the sliced mushrooms and minced garlic. Sauté until the mushrooms are tender and golden brown, about 5-7 minutes. Season with salt and pepper to taste. Remove from heat and set aside.",
                    "Preheat the oven to 375°F (190°C).",
                    "Place the baguette slices on a baking sheet. Brush each slice lightly with extra virgin olive oil on one side. Toast in the preheated oven for 5-7 minutes, or until golden brown and crispy.",
                    "Remove the toasted baguette slices from the oven. Spread goat cheese over each slice.",
                    "Top the goat cheese with the sautéed mushroom mixture, dividing it evenly among the slices.",
                    "Garnish with chopped fresh parsley.",
                    "Serve immediately as an elegant appetizer or snack. Enjoy the savory combination of mushrooms and goat cheese on bruschetta!"
                ]
            },
            {
                name: "Avocado and Tomato Bruschetta",
                ingredients: [
                    "2 ripe avocados",
                    "1 tablespoon lime juice",
                    "Salt and pepper to taste",
                    "1 tomato, diced",
                    "1 clove garlic, minced",
                    "2 tablespoons red onion, finely chopped",
                    "2 tablespoons fresh cilantro, chopped",
                    "1 baguette, sliced",
                    "Extra virgin olive oil, for brushing"
                ],
                steps: [
                    "In a bowl, mash the ripe avocados with lime juice until smooth. Season with salt and pepper to taste.",
                    "Add the diced tomato, minced garlic, chopped red onion, and fresh cilantro to the mashed avocado. Mix well to combine.",
                    "Preheat the oven to 375°F (190°C).",
                    "Place the baguette slices on a baking sheet. Brush each slice lightly with extra virgin olive oil on one side. Toast in the preheated oven for 5-7 minutes, or until golden brown and crispy.",
                    "Remove the toasted baguette slices from the oven. Spread the avocado mixture over each slice.",
                    "Serve immediately as a delightful appetizer or snack. Enjoy the creamy avocado and fresh tomato flavors on bruschetta!"
                ]
            }
        ]
    
    };


    function getRecipeNameFromURL() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('recipe') || 'Spaghetti Bolognese'; // Default to 'Spaghetti Bolognese'
    }

    function loadRecipe(recipeName, index = 0) {
        const title = document.getElementById("recipe-title");
        title.textContent = recipeName;

        const content = document.getElementById("recipe-content");
        let ingredientsList = '';
        let stepsList = '';

        if (recipes[recipeName] && recipes[recipeName][index]) {
            const { ingredients, steps } = recipes[recipeName][index];
            ingredientsList = ingredients.map(ingredient => `<li contenteditable="true">${ingredient}</li>`).join("");
            stepsList = steps.map(step => `<li contenteditable="true">${step}</li>`).join("");
        } else {
            ingredientsList = `
                <li contenteditable="true"></li>
                <li contenteditable="true"></li>
                <li contenteditable="true"></li>
            `;
            stepsList = `
                <li contenteditable="true"></li>
                <li contenteditable="true"></li>
                <li contenteditable="true"></li>
            `;
        }

        content.innerHTML = `
            <h2>Ingredients:</h2>
            <ul id="ingredients-list">${ingredientsList}</ul>
            <h2>Steps:</h2>
            <ol id="steps-list">${stepsList}</ol>
        `;

        updateButtons(index, recipeName);
    }

    function updateButtons(index, recipeName) {
        const nextButton = document.getElementById("next-recipe");
        const prevButton = document.getElementById("prev-recipe");
        const saveButton = document.getElementById("save-recipe");
        const deleteButton = document.getElementById("delete-recipe");

        prevButton.style.display = (index === 0) ? 'none' : 'inline-block';
        nextButton.style.display = (index >= recipes[recipeName].length - 1) ? 'inline-block' : 'inline-block';
        if (index >= 3) {
            saveButton.style.display = 'inline-block';
            deleteButton.style.display = 'inline-block';
       }
    }
    const currentRecipeName = getRecipeNameFromURL();
    let currentRecipeIndex = 0;

    function saveRecipe() {
        const ingredients = Array.from(document.querySelectorAll("#ingredients-list li")).map(li => li.textContent.trim()).filter(text => text.length > 0);
        const steps = Array.from(document.querySelectorAll("#steps-list li")).map(li => li.textContent.trim()).filter(text => text.length > 0);

        if (recipes[currentRecipeName][currentRecipeIndex]) {
            recipes[currentRecipeName][currentRecipeIndex] = { ingredients, steps };
        } else {
            recipes[currentRecipeName].push({ ingredients, steps });
        }

        localStorage.setItem('userRecipes', JSON.stringify(recipes));
        alert('Recipe saved successfully!');
    }

    function deleteRecipe() {
        if (confirm('Are you sure you want to delete this recipe?')) {
            recipes[currentRecipeName].splice(currentRecipeIndex, 1);
            if (recipes[currentRecipeName].length === 0) {
                delete recipes[currentRecipeName];
            }
            localStorage.setItem('userRecipes', JSON.stringify(recipes));
            location.reload();
        }
    }

    document.getElementById("next-recipe").addEventListener("click", function() {
        if (currentRecipeIndex < recipes[currentRecipeName].length - 1) {
            currentRecipeIndex++;
        } else {
            currentRecipeIndex++;
        }
        loadRecipe(currentRecipeName, currentRecipeIndex);
    });

    document.getElementById("prev-recipe").addEventListener("click", function() {
        if (currentRecipeIndex > 0) {
            currentRecipeIndex--;
            loadRecipe(currentRecipeName, currentRecipeIndex);
        }
    });

    document.getElementById("save-recipe").addEventListener("click", saveRecipe);
    document.getElementById("delete-recipe").addEventListener("click", deleteRecipe);

    loadRecipe(currentRecipeName, currentRecipeIndex);
});
// Function to save recipes to localStorage
function saveRecipesToLocalStorage() {
    localStorage.setItem('userRecipes', JSON.stringify(recipes));
}

// Function to load recipes from localStorage
function loadRecipesFromLocalStorage() {
    recipes = JSON.parse(localStorage.getItem('userRecipes')) || {};
}

// Function to save a recipe
function saveRecipe() {
    const ingredients = Array.from(document.querySelectorAll("#ingredients-list li")).map(li => li.textContent.trim()).filter(text => text.length > 0);
    const steps = Array.from(document.querySelectorAll("#steps-list li")).map(li => li.textContent.trim()).filter(text => text.length > 0);

    if (!recipes[currentRecipeName]) {
        recipes[currentRecipeName] = [];
    }

    if (recipes[currentRecipeName][currentRecipeIndex]) {
        recipes[currentRecipeName][currentRecipeIndex] = { ingredients, steps };
    } else {
        recipes[currentRecipeName].push({ ingredients, steps });
    }

    saveRecipesToLocalStorage();
    alert('Recipe saved successfully!');
}

// Function to delete a recipe
function deleteRecipe() {
    if (confirm('Are you sure you want to delete this recipe?')) {
        recipes[currentRecipeName].splice(currentRecipeIndex, 1);
        if (recipes[currentRecipeName].length === 0) {
            delete recipes[currentRecipeName];
        }
        saveRecipesToLocalStorage();
        location.reload();
    }
}

// Load recipes when the page loads
window.addEventListener('load', () => {
    loadRecipesFromLocalStorage();
    loadRecipe(currentRecipeName, currentRecipeIndex);
});