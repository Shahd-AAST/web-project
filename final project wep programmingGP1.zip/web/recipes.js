document.addEventListener("DOMContentLoaded", function() {
    const initialRecipes = [
        { name: "Spaghetti Bolognese", image: "spaghetti.jpg", link: "recipeName.html?recipe=Spaghetti%20Bolognese" },
        { name: "Chicken Curry", image: "chicken_curry.jpg", link: "recipeName.html?recipe=Chicken%20Curry" },
        { name: "Beef Stroganoff", image: "beef_stroganoff.jpg", link: "recipeName.html?recipe=Beef%20Stroganoff" },
        { name: "Caesar Salad", image: "caesar_salad.jpg", link: "recipeName.html?recipe=Caesar%20Salad" },
        { name: "Vegetarian Pizza", image: "vegetarian_pizza.jpg", link: "recipeName.html?recipe=Vegetarian%20Pizza" },
        { name: "Tacos", image: "tacos.jpg", link: "recipeName.html?recipe=Tacos" },
        { name: "Sushi", image: "sushi.jpg", link: "recipeName.html?recipe=Sushi" },
        { name: "Pancakes", image: "pancakes.jpg", link: "recipeName.html?recipe=Pancakes" },
        { name: "Grilled Cheese Sandwich", image: "grilled_cheese.jpg", link: "recipeName.html?recipe=Grilled%20Cheese%20Sandwich" },
        { name: "French Onion Soup", image: "french_onion_soup.jpg", link: "recipeName.html?recipe=French%20Onion%20Soup" },
        { name: "Apple Pie", image: "apple_pie.jpg", link: "recipeName.html?recipe=Apple%20Pie" },
        { name: "BBQ Ribs", image: "bbq_ribs.jpg", link: "recipeName.html?recipe=BBQ%20Ribs" },
        { name: "Pad Thai", image: "pad_thai.jpg", link: "recipeName.html?recipe=Pad%20Thai" },
        { name: "Chicken Alfredo", image: "chicken_alfredo.jpg", link: "recipeName.html?recipe=Chicken%20Alfredo" },
        { name: "Lasagna", image: "lasagna.jpg", link: "recipeName.html?recipe=Lasagna" },
        { name: "Chocolate Cake", image: "chocolate_cake.jpg", link: "recipeName.html?recipe=Chocolate%20Cake" },
        { name: "Tiramisu", image: "tiramisu.jpg", link: "recipeName.html?recipe=Tiramisu" },
        { name: "Bruschetta", image: "bruschetta.jpg", link: "recipeName.html?recipe=Bruschetta" }
    ];

    function getSavedRecipes() {
        const savedRecipes = localStorage.getItem('recipes');
        return savedRecipes ? JSON.parse(savedRecipes) : [];
    }

    function saveRecipes(recipes) {
        localStorage.setItem('recipes', JSON.stringify(recipes));
    }

    function addRecipeToDOM(recipe, isUserAdded = false) {
        const recipeList = document.getElementById("recipe-list");

        const recipeItem = document.createElement("div");
        recipeItem.classList.add("recipe-item");

        if (recipe.image) {
            const recipeImage = document.createElement("img");
            recipeImage.src = recipe.image;
            recipeImage.alt = recipe.name;
            recipeItem.appendChild(recipeImage);
        }

        const recipeName = document.createElement("a");
        recipeName.href = recipe.link;
        recipeName.textContent = recipe.name;
        recipeItem.appendChild(recipeName);

        if (isUserAdded) {
            const deleteButton = document.createElement("button");
            deleteButton.textContent = "Delete";
            deleteButton.classList.add("delete-button");
            deleteButton.onclick = function() {
                recipeList.removeChild(recipeItem);
                const userRecipes = getSavedRecipes().filter(r => r.name !== recipe.name);
                saveRecipes(userRecipes);
            };
            recipeItem.appendChild(deleteButton);
        }

        recipeList.appendChild(recipeItem);
    }

    // Load initial and saved recipes
    const initialRecipeNames = initialRecipes.map(recipe => recipe.name);
    const userRecipes = getSavedRecipes();
    const allRecipes = [...initialRecipes, ...userRecipes];

    allRecipes.forEach(recipe => {
        const isUserAdded = !initialRecipeNames.includes(recipe.name);
        addRecipeToDOM(recipe, isUserAdded);
    });

    // Create "Add Recipe" placeholder
    const addRecipeItem = document.createElement("div");
    addRecipeItem.classList.add("recipe-item");
    addRecipeItem.id = "add-recipe";

    const addRecipeImage = document.createElement("img");
    addRecipeImage.src = "add_image_icon.jpg"; // Placeholder icon image
    addRecipeImage.alt = "Add Recipe";

    const addRecipeName = document.createElement("a");
    addRecipeName.href = "#";
    addRecipeName.textContent = "Add a Recipe";
    addRecipeName.addEventListener("click", function() {
        document.getElementById("add-recipe-modal").style.display = "block";
    });

    addRecipeItem.appendChild(addRecipeImage);
    addRecipeItem.appendChild(addRecipeName);
    document.getElementById("recipe-list").appendChild(addRecipeItem);

    // Handle modal close
    const modal = document.getElementById("add-recipe-modal");
    const closeModal = document.querySelector(".close");
    closeModal.addEventListener("click", function() {
        modal.style.display = "none";
    });
    window.addEventListener("click", function(event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });
    
    // Handle form submission for adding new recipes
    const addRecipeForm = document.getElementById("add-recipe-form");
    addRecipeForm.addEventListener("submit", function(event) {
        event.preventDefault();
    
        const recipeNameInput = document.getElementById("recipe-name");
        const recipeImageInput = document.getElementById("recipe-image");
    
        // Validate form inputs
        if (!recipeNameInput.value.trim() || !recipeImageInput.files.length) {
            alert("Please fill out both the recipe name and image.");
            return;
        }
    
        const reader = new FileReader();
        reader.onload = function(e) {
            const newRecipe = {
                name: recipeNameInput.value,
                link: `newrecipe.html?recipe=${encodeURIComponent(recipeNameInput.value)}`,
                image: e.target.result // Base64 encoded image
            };
    
            // Add new recipe to the DOM
            addRecipeToDOM(newRecipe, true);
    
            // Save the new recipe to local storage
            const updatedRecipes = [...getSavedRecipes(), newRecipe];
            saveRecipes(updatedRecipes);
    
            // Clear the form fields and close the modal
            recipeNameInput.value = "";
            recipeImageInput.value = "";
            modal.style.display = "none";
        };
    
        reader.readAsDataURL(recipeImageInput.files[0]);
    });
    
    // Search functionality
    const searchInput = document.getElementById("search-input");
    const searchButton = document.getElementById("search-button");
    
    searchButton.addEventListener("click", function() {
        const searchQuery = searchInput.value.trim().toLowerCase();
        const foundRecipes = allRecipes.filter(recipe => recipe.name.toLowerCase().includes(searchQuery));
    
        if (foundRecipes.length === 0) {
            alert("No recipes found matching the search query.");
            return;
        }
    
        // Clear existing recipes from the DOM
        document.getElementById("recipe-list").innerHTML = "";
    
        // Add found recipes to the DOM
        foundRecipes.forEach(recipe => addRecipeToDOM(recipe, initialRecipeNames.includes(recipe.name)));
    });
    
    });
    