document.addEventListener("DOMContentLoaded", function() {
    const signupForm = document.getElementById("signup-form");
    const fullNameInput = document.getElementById("full-name");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const confirmPasswordInput = document.getElementById("confirm-password");

    signupForm.addEventListener("submit", function(event) {
        event.preventDefault();
        let valid = true;

        const fullName = fullNameInput.value.trim();
        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();
        const confirmPassword = confirmPasswordInput.value.trim();

        if (fullName === "" || email === "" || password === "" || confirmPassword === "") {
            alert("All fields are required.");
            valid = false;
        }

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            alert("Please enter a valid email address.");
            valid = false;
        }

        if (password !== confirmPassword) {
            alert("Passwords do not match.");
            valid = false;
        }

        const passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
        if (!passwordPattern.test(password)) {
            alert("Password must be at least 8 characters long and contain at least one number, one uppercase, and one lowercase letter.");
            valid = false;
        }

        const predefinedUsers = [
            { email: "somaya@gmail.com", password: "Somaya123**" },
            { email: "monica@gmail.com", password: "Monica123**" },
            { email: "shahad@gmail.com", password: "Shahad123**" },
            { email: "jana@gmail.com", password: "Jana123**" },
        ];

        // Check if the email is already in use
        const storedUsers = JSON.parse(localStorage.getItem('users')) || [];
        const isEmailUsed = storedUsers.some(user => user.email === email) || predefinedUsers.some(user => user.email === email);
        const isPasswordUsed = storedUsers.some(user => user.password === password) || predefinedUsers.some(user => user.password === password);

        if (isEmailUsed) {
            alert("This email is already in use. Please re-enter your data.");
            emailInput.value = "";
            passwordInput.value = "";
            confirmPasswordInput.value = "";
            valid = false;
        }

        if (isPasswordUsed) {
            alert("This password is already in use. Please re-enter your data.");
            emailInput.value = "";
            passwordInput.value = "";
            confirmPasswordInput.value = "";
            valid = false;
        }

        if (valid) {
            const newUser = { email, password };
            storedUsers.push(newUser);
            localStorage.setItem('users', JSON.stringify(storedUsers));
            alert("Sign up successful!");
            window.location.href = "home.html";
        }
    });
});
