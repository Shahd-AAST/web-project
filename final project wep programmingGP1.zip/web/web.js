document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.getElementById("login-form");
    const emailInput = document.getElementById("login-email");
    const passwordInput = document.getElementById("login-password");

    const predefinedUsers = [
        { email: "somaya@gmail.com", password: "Somaya123**" },
        { email: "monica@gmail.com", password: "Monica123**" },
        { email: "shahad@gmail.com", password: "Shahad123**" },
        { email: "jana@gmail.com", password: "Jana123**" },
    ];

    function validateUser(email, password) {
        // Check predefined users
        for (const user of predefinedUsers) {
            if (user.email === email && user.password === password) {
                return true;
            }
        }
        // Check users in localStorage
        const storedUsers = JSON.parse(localStorage.getItem('users')) || [];
        return storedUsers.some(user => user.email === email && user.password === password);
    }

    loginForm.addEventListener("submit", function(event) {
        event.preventDefault();

        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();

        if (email === "" || password === "") {
            alert("Please enter both email and password.");
            return;
        }

        if (validateUser(email, password)) {
            alert("Logged in successfully!");
            window.location.href = "recipes.html";
        } else {
            alert("Invalid email or password.");
            window.location.href = "signup.html";
        }
    });
});document.addEventListener("DOMContentLoaded", function() {
    var carouselItems = document.querySelectorAll('.carousel-item');
    var currentIndex = 0;
    var interval;

    function showSlide(index) {
        // Hide all slides
        carouselItems.forEach(function(item) {
            item.classList.remove('active');
        });
        // Show the slide at the given index
        carouselItems[index].classList.add('active');
    }

    function nextSlide() {
        showSlide(currentIndex);
        currentIndex++;
        // Check if the last item has been displayed
        if (currentIndex === carouselItems.length) {
            // Hide all slides after the last one is shown
            setTimeout(function() {
                carouselItems.forEach(function(item) {
                    item.classList.remove('active');
                });
                // Reset index after showing all slides
                currentIndex = 0;
            }, 1500);
        }
    }

    // Start the carousel
    interval = setInterval(nextSlide, 1500);
});
